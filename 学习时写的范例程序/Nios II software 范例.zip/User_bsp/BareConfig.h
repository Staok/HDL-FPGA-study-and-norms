#ifndef __BARECONFIOG_H
#define __BARECONFIOG_H

#include <stdio.h>
// #include "string.h"
// #include "stdlib.h"
#include "alt_types.h"
#include <unistd.h>		//包含 usleep 等头文件

#include "system.h"
#include "altera_avalon_sysid_qsys_regs.h" // sysid

#include "timer.h"
#include "pio.h"

void Bare_Begin(void);

#endif


