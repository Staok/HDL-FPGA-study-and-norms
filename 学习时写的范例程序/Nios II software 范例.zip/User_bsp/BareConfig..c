#include "BareConfig.h"



void Bare_Begin(void)
{
	/* 初始化序列 */
	
	sys_timer_Initial_with_irq();	/* timer 初始化 带中断 */
	sys_pio_Initial_with_irq();		/* PIO 初始化 带中断 */
	
	
	
	for(;;)
	{
		/*____________10ms 周期 要做的事情____________________________________*/
		if(Timer_IT_flags._10msec_flag)
		{
			Timer_IT_flags._10msec_flag = FALSE;
			
		}
		
		
		/*____________100ms 周期 要做的事情____________________________________*/
		if(Timer_IT_flags._100msec_flag)
        {
            Timer_IT_flags._100msec_flag = FALSE;
			
			
		}
		
		
		/*____________300ms 周期 要做的事情____________________________________*/
		if(Timer_IT_flags._300msec_flag)
		{
			Timer_IT_flags._300msec_flag = FALSE;
			
		}
		
		
		/*____________1s 周期 要做的事情____________________________________*/
		if(Timer_IT_flags._1sec_flag)
		{
			Timer_IT_flags._1sec_flag = FALSE;
			
		}
		
		
		/*____________1min 周期 要做的事情____________________________________*/
		if(Timer_IT_flags._1min_flag)
		{
			Timer_IT_flags._1min_flag = FALSE;
			
			
		}
	}
}

