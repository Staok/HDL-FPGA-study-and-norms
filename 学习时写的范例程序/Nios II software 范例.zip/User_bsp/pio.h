#ifndef __PIO_H
#define __PIO_H

#include "system.h"
#include "altera_avalon_pio_regs.h"		// PIO
#include "sys/alt_irq.h"				// irq
#include <stdio.h>

	/* PIO 初始化 带中断 */
	void sys_pio_Initial_with_irq(void);
	/* PIO_3PIN_IN_BASE 中断服务函数 */
	void sys_PIO_IRQ_ISR(void* isr_context);
	
	/* 经过试验，QII 13.1环境，下面这种直接操作寄存器的方法不能用，别用 */
	// typedef struct
	// {
		// unsigned long int DATA;				/* PIO 电平的读写 */
		
		// unsigned long int DIRECTION;		/* 	此寄存器仅存在于 bidirectional 模式，
												// 写 0 为输入，写 1 为输出并输出 DATA 寄存器对应位的值 */
		
		// unsigned long int INTERRUPT_MASK;	/* 	此寄存器近存在于 generate IRQs 选项启用时
												// 写 1 使能对应位的中断，上电默认为全 0 */
		
		// unsigned long int EDGE_CAPTURE;		/* 	此寄存器仅存在于 capture edges 选项启用时
												// 写 1 清除对应位的中断标志位 */
	// }PIO_STR;

	//#define PIO_12PIN_OUT ((PIO_STR *)PIO_12PIN_OUT_BASE)
	//#define PIO_3PIN_IN ((PIO_STR *)PIO_3PIN_IN_BASE)
	//PIO_STR* PIO_12PIN_OUT = (PIO_STR *)PIO_12PIN_OUT_BASE;
	//PIO_STR* PIO_3PIN_IN = (PIO_STR *)PIO_3PIN_IN_BASE;


#endif


