#include "pio.h"


/* PIO 初始化 带中断 */
void sys_pio_Initial_with_irq(void)
{
	//使能 PIO IRQ
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_3PIN_IN_BASE, 0x07); // PIO_3PIN_IN_BASE 清中断边沿捕获寄存器 0x07 0000 0111
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_3PIN_IN_BASE, 0x07); // PIO_3PIN_IN_BASE 使能中断 0x07 0000 0111
	
	// 注册 PIO IRQ
	alt_ic_isr_register(
		PIO_3PIN_IN_IRQ_INTERRUPT_CONTROLLER_ID,	// 中断控制器标号，从system.h复制
		PIO_3PIN_IN_IRQ,							// 硬件中断号，从system.h复制
		sys_PIO_IRQ_ISR,							// 中断服务子函数
		NULL,										// 指向与设备驱动实例相关的数据结构体，可设为 NULL
		0x0);										// flags，保留未用
}


/* PIO_3PIN_IN_BASE 中断服务函数 */
void sys_PIO_IRQ_ISR(void* isr_context)
{
	// PIO_3PIN_IN_BASE 第一位（0x01 0000 0001） IO 中断
	if(IORD_ALTERA_AVALON_PIO_DATA(PIO_3PIN_IN_BASE) & 0x01)
	{
		IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_3PIN_IN_BASE, 0x01); // 清中断边沿捕获寄存器
	}
	
	// PIO_3PIN_IN_BASE 第二位（0x02 0000 0010） IO 中断
	if(IORD_ALTERA_AVALON_PIO_DATA(PIO_3PIN_IN_BASE) & 0x02)
	{
		IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_3PIN_IN_BASE, 0x02); // 清中断边沿捕获寄存器
	}
	
	// PIO_3PIN_IN_BASE 第三位（0x04 0000 0100） IO 中断
	if(IORD_ALTERA_AVALON_PIO_DATA(PIO_3PIN_IN_BASE) & 0x04)
	{
		IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_3PIN_IN_BASE, 0x04); // 清中断边沿捕获寄存器
	}
}


