#include "BareConfig.h"


/* 本 Nios II 系统外设概述

sopcinfo： 			niosii_qsys.sopcinfo
PIO_3PIN_IN： 		3位 PIO 输入，上升沿中断（Qsys设定后不能改），Enable bit-clearing for edge capture register
PIO_12PIN_OUT：		12位 PIO 输出，Enable individual bit set/clear output register
TIMER_0_1MS：		32位定时器0 Qsys 设置周期 1ms
TIMER_1_10MS：		32位定时器1 Qsys 设置周期 10ms


System Clock（使用alt_alarm_start()实现定时中断） 和 Timestamp（使用alt_timestamp_start()实现开机计数的计时） 均选 none

*/

/*
中断服务函数说明

注意：
	0 中断服务函数中必须清标志位
	1 中断服务代码区不要使用printf()，否则会严重阻塞中断。
	2 如果需要中断服务子函数传参，那么参数必须转为空类型。且所传参数为16位的全局变量。
*/

alt_u32 sys_id = NULL;	//系统ID，由Qsys设定

int main()
{
	usleep(500000);	//等待系统上电稳定 演示500ms
	
//	sys_id = IORD_ALTERA_AVALON_SYSID_QSYS_ID(SYSID_BASE);	//读取系统ID，由Qsys设定
	
	printf("sysid: %ld , Hello from Nios II!\n",sys_id);
	printf("Nios II start running!\n");

	Bare_Begin();	//进入裸机主循环

	return 0;
}


