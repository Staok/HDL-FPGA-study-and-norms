#include "timer.h"

/* timer 初始化 带中断 */
void sys_timer_Initial_with_irq(void)
{
	// 使能 Timer0_1ms IRQ
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_0_1MS_BASE, 0x00);				//清除 Timer0 中断标志寄存器
	// IOWR_ALTERA_AVALON_TIMER_PERIODL(TIMER_0_1MS_BASE, 80000000);		//设置 Timer0 周期
	// IOWR_ALTERA_AVALON_TIMER_PERIODH(TIMER_0_1MS_BASE, 80000000 >> 16);
	IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_0_1MS_BASE, 0x07);				//允许 Timer0 中断
	// 注册 Timer0_1ms IRQ
	alt_ic_isr_register(
		TIMER_0_1MS_IRQ_INTERRUPT_CONTROLLER_ID,
		TIMER_0_1MS_IRQ,
		sys_Timer0_1ms_IRQ_ISR,
		(void *)TIMER_0_1MS_BASE,
		0x0);
	
	
	// 使能 Timer1_10ms IRQ
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_1_10MS_BASE, 0x00);				//清除 Timer1 中断标志寄存器
	// IOWR_ALTERA_AVALON_TIMER_PERIODL(TIMER_1_10MS_BASE, 80000000);		//设置 Timer1 周期
	// IOWR_ALTERA_AVALON_TIMER_PERIODH(TIMER_1_10MS_BASE, 80000000 >> 16);
	IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_1_10MS_BASE, 0x07);				//允许 Timer1 中断
	// 注册 Timer1_10ms IRQ
	alt_ic_isr_register(
		TIMER_1_10MS_IRQ_INTERRUPT_CONTROLLER_ID,
		TIMER_1_10MS_IRQ,
		sys_Timer1_10ms_IRQ_ISR,
		(void *)TIMER_1_10MS_BASE,
		0x0);

/*
 * 以上的清标志位、设置周期和使能部分也可以用下面替代

	// 设置PERIOD寄存器
	// PERIODH << 16 | PERIODL = 计数器周期因子 * 系统时钟频率因子 - 1
	// PERIODH << 16 | PERIODL = 5m*100M - 1 = 499999 = 0x7A11F
	IOWR_ALTERA_AVALON_TIMER_PERIODH(HIGH_RES_TIMER_BASE, 0x0007);
	IOWR_ALTERA_AVALON_TIMER_PERIODL(HIGH_RES_TIMER_BASE, 0xA11F);

	// 设置CONTROL寄存器
	//    位数 |  3   |  2   |  1   |  0  |
	// CONTROL | STOP | START| CONT | ITO |
	// ITO   1，产生IRO；                      0，不产生IRQ
	// CONT  1，计数器连续运行直到STOP被置一；   0，计数到0停止
	// START 1，计数器开始运行；                0，无影响
	// STOP  1，计数器停止运行；                0，无影响
	IOWR_ALTERA_AVALON_TIMER_CONTROL(HIGH_RES_TIMER_BASE, \
		ALTERA_AVALON_TIMER_CONTROL_START_MSK | \ // START = 1
		ALTERA_AVALON_TIMER_CONTROL_CONT_MSK  | \ // CONT  = 1
		ALTERA_AVALON_TIMER_CONTROL_ITO_MSK);     // ITO   = 1
 * */
}


/* 定时器0 1ms 中断服务子函数 */
void sys_Timer0_1ms_IRQ_ISR(void* isr_context)
{
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_0_1MS_BASE, 0);	//清除 Timer 中断标志寄存器
	
	
}


struct timer_IT_struct Timer_IT_flags = 
{
	._10msec_flag 	= 0,
	._10msec 		= 0,
	._100msec_flag 	= 0,
	._100msec 		= 0,
	._300msec_flag 	= 0,
	._1sec_flag  	= 0,
	._1sec 			= 0,
	._1min_flag 	= 0,
	._1min 			= 0
};

/* 定时器1 10ms 中断服务子函数 */
void sys_Timer1_10ms_IRQ_ISR(void* isr_context)
{
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_1_10MS_BASE, 0);	//清除 Timer 中断标志寄存器
	
	Timer_IT_flags._10msec_flag = TRUE;
	
	if(++Timer_IT_flags._10msec % 10 == 0)
	{
		
		Timer_IT_flags._100msec_flag = TRUE;
		Timer_IT_flags._100msec++;
	}
	
	if(Timer_IT_flags._10msec >= 30)
	{
		Timer_IT_flags._10msec = 0;
		Timer_IT_flags._300msec_flag = TRUE;
	}
	
	if(Timer_IT_flags._100msec >= 10)
	{
		Timer_IT_flags._100msec = 0;
		Timer_IT_flags._1sec_flag = TRUE;
		Timer_IT_flags._1sec++;
	}
	
	if(Timer_IT_flags._1sec >= 60)
	{
		Timer_IT_flags._1sec = 0;
		Timer_IT_flags._1min_flag = TRUE;
		Timer_IT_flags._1min++;
		
		if((Timer_IT_flags._1min > 666))
		{
			Timer_IT_flags._1min = 0;
			
			//超过时间，可以设定强制关闭
			//_OutofTime_Running_flag = 1;
			//CTRL_DCDC_ON_OFF = DCDC_OFF;
		}
	}
}


