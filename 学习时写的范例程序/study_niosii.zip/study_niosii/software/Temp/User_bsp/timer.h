#ifndef __TIMER_H
#define __TIMER_H

#include "system.h"
#include "altera_avalon_timer_regs.h"	// timer
#include "sys/alt_irq.h"				// irq
	
	#define TRUE  1
	#define FALSE 0
	
	struct timer_IT_struct
	{
		alt_u8 _10msec_flag;	//10毫秒标志和计数
		alt_u16 _10msec;
		
		alt_u8 _100msec_flag;	//100毫秒标志和计数
		alt_u16 _100msec;
		
		alt_u8 _300msec_flag;	//300毫秒标志
		
		alt_u8 _1sec_flag;		//1秒标志和计数
		alt_u16 _1sec;
		
		alt_u8 _1min_flag;		//1分钟标志和计数
		alt_u16 _1min;
	};
	
	extern struct timer_IT_struct Timer_IT_flags;

	/* timer 初始化 带中断 */
	void sys_timer_Initial_with_irq(void);
	/* 定时器0 1ms 中断服务子函数 */
	void sys_Timer0_1ms_IRQ_ISR(void* isr_context);
	/* 定时器1 10ms 中断服务子函数 */
	void sys_Timer1_10ms_IRQ_ISR(void* isr_context);
	
#endif
