// --------------------------------------------------------------------
// Copyright (c) 2010 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------


/*
 * st_pattern_gen.h
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#ifndef ST_PATTERN_GEN_H_
#define ST_PATTERN_GEN_H_

//SPG: AV-Stream Pattern Generator
#define SPG_ENALBE				0x00	// RW
#define SPG_PATTERN_SELECT		0x01	// RW
#define SPG_INJECT_ERROR		0x02	// RW
#define SPG_PREAMBLE_CONTROL	0x03	// RW
#define SPG_PREAMBLE_CHAR_LOW	0x04	// RW
#define SPG_PREAMBLE_CHAR_HI	0x05	// RW

// pattern Enable register
#define SPG_ENABLE_BIT_ENALBE	0x01

// Pattern Select register
#define SPG_PATTERN_BIT_PRBS7	0x01
#define SPG_PATTERN_BIT_PRBS15	0x02
#define SPG_PATTERN_BIT_PRBS23	0x04
#define SPG_PATTERN_BIT_PRBS31	0x08
#define SPG_PATTERN_BIT_HF		0x10  // high-frequency
#define SPG_PATTERN_BIT_LF		0x20  // low-frequency

// Inject Error Register
#define SPG_INJET_ERROR_BIT_ENABLE	0x01

// Preamble Control Register
#define SPG_PREAMBLE_BIT_ENABLE		0x01
#define SPG_PREAMBLE_BIT_NUM_BITS	0x0F00

// Preamble Character Low Register
#define SPG_PREAMBLE_CHAR_LOW_BIT	0xFFFFFFFF

// Preamble Character High Register
#define SPG_PREAMBLE_CHAR_HI_BOT	0xFF


void SPG_Enable(alt_u32 BaseAddr, bool bEnable);
void SPG_PatternSet(alt_u32 BaseAddr, alt_u32 PatternID);
void SPG_InjectError(alt_u32 BaseAddr, bool bEnable);
void SPG_Preamble(alt_u32 BaseAddr, bool bEnable, alt_u8 NumBeats);
void SPG_PreambleCharSet(alt_u32 BaseAddr, alt_u8 HiChar, alt_u32 LowChar);

#endif /* ST_PATTERN_GEN_H_ */
