// --------------------------------------------------------------------
// Copyright (c) 2012 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------

#include "terasic_includes.h"
#include "xcvr_reconfig.h"
#include "st_pattern_gen.h"
#include "st_pattern_checker.h"
#include "xcvr_test.h"
#include "system.h"
#include "alt_types.h"
#include "altera_avalon_pio_regs.h"
#include "LED.h"


#define PARALLEL_MODE 0x01;


typedef enum{
	CH_HSMC_XCVR0 = 0,
	CH_HSMC_XCVR1,
	CH_HSMC_XCVR2,
	CH_HSMC_XCVR3,
	CH_NUM
}CHANNEL_ID;

typedef struct{
	int PhysicalChannel;
	alt_u32 Xcvr_Base;
	alt_u32 Generater_Base;
	alt_u32 Checker_Base;
}CHANNEL_INFO;

static CHANNEL_INFO gszChannelInfo[] = {
		{1*2,  HSMC_XCVR_0_XCVR_CUSTOM_PHY_0_BASE, HSMC_XCVR_0_DATA_PATTERN_GENERATOR_0_BASE,HSMC_XCVR_0_DATA_PATTERN_CHECKER_0_BASE},  // HSMC_XCVR1
		{2*2,  HSMC_XCVR_1_XCVR_CUSTOM_PHY_0_BASE, HSMC_XCVR_1_DATA_PATTERN_GENERATOR_0_BASE,HSMC_XCVR_1_DATA_PATTERN_CHECKER_0_BASE},  // HSMC_XCVR2
		{3*2,  HSMC_XCVR_2_XCVR_CUSTOM_PHY_0_BASE, HSMC_XCVR_2_DATA_PATTERN_GENERATOR_0_BASE,HSMC_XCVR_2_DATA_PATTERN_CHECKER_0_BASE},  // HSMC_XCVR3
		{4*2,  HSMC_XCVR_3_XCVR_CUSTOM_PHY_0_BASE, HSMC_XCVR_3_DATA_PATTERN_GENERATOR_0_BASE,HSMC_XCVR_3_DATA_PATTERN_CHECKER_0_BASE},  // HSMC_XCVR4
};

bool TEST_XCVR_ALL_PARALLEL(void);
int TxVod = 50;
int TxPostTap = 18;
int RxEq = 2;
int TestPattern = PATTERN_PRBS31;
int TestTimeDur = 1; // unit in second
bool bInternalLoopback = FALSE;


void MGM_Reset(void){

    // reset hsmc_xcvr phy
    IOWR(RESET_HSMC_XCVR_PHY_BASE, 0x00, 0x00);
    IOWR(RESET_HSMC_XCVR_PHY_BASE, 0x00, 0x01);

    usleep(2*1000);
    IOWR(RESET_HSMC_XCVR_PHY_BASE, 0x00, 0x00);

    // reset xcvr config
    IOWR(RESET_XCVR_CONFIG_BASE, 0x00, 0x00);
    IOWR(RESET_XCVR_CONFIG_BASE, 0x00, 0x01);
    usleep(2*1000);
    IOWR(RESET_XCVR_CONFIG_BASE, 0x00, 0x00);

    usleep(150*1000); // wait stable (necessary!!! must larger than 50ms, otherwise, failed to configure the reconfig controller)
}


void XCVR_QueryChannelName(alt_u32 nChannel, char szName[])
{
	switch(nChannel){
		case CH_HSMC_XCVR0: strcpy(szName, "HSMC_XCVR_0"); break;
		case CH_HSMC_XCVR1: strcpy(szName, "HSMC_XCVR_1"); break;
		case CH_HSMC_XCVR2: strcpy(szName, "HSMC_XCVR_2"); break;
		case CH_HSMC_XCVR3: strcpy(szName, "HSMC_XCVR_3"); break;
	}
}

int main(void)
{
	LED_AllOff( );
    printf("--------C5G HSMC XCVR LOOPBACK demo--------\r\n");
    printf("ensure the hsmc loopback daughter card  is installed\r\n");
    printf("LEDG0~LEDG3 on indicate the related xcvr channel test pass \r\n");
    printf("The system report test result every 5 seconds \r\n");
    printf(" the test will continue and press key0~key3 to terminate test\r\n");
    LED_AllOff( );
    printf("test .......\r\n ");
    while(1)
    {
    	TEST_XCVR_ALL_PARALLEL();
    	//while(IORD_ALTERA_AVALON_PIO_DATA(BUTTON_BASE) == 0x0f);
    	//printf("test again....\r\n ");
    }
    return 0;
}



bool TEST_XCVR_ALL_PARALLEL(void)
{
	bool bPass = TRUE, bError;
	int i, nErrChNum=0;
	alt_u32 Xcvr_Base;
	alt_u32 Generator_Base;
	alt_u32 Checker_Base;
	bool szError[CH_NUM];
	alt_u64 NumCnt;
	alt_u64 ErrCnt;
	bool bDone = FALSE;
	alt_u32 Timeout, Time2Report, TimeStart, TimeElapsed;
	const alt_u32 TimeDur = alt_ticks_per_second()*200;
	const alt_u32 TimeReportDur = alt_ticks_per_second()*5;
	int PhysicalChannel;
	char szChannelName[64];
	alt_u64 szNumCnt[CH_NUM];
	alt_u64 szErrCnt[CH_NUM];
	alt_u32 szElapsed[CH_NUM];
	printf("test all xcvr channels in parallel\r\n");
	//printf("All Xcvr Channel Test...\r\n");
	for(i=0;i<CH_NUM;i++){
		szError[i] = FALSE;
		szNumCnt[i] = 0;
		szErrCnt[i] = 0;
	}
	MGM_Reset();
	for(i=0;i<CH_NUM;i++)
	{
		Xcvr_Base = gszChannelInfo[i].Xcvr_Base;
		PhysicalChannel = gszChannelInfo[i].PhysicalChannel;

		// xcvr configure: internal loopback
		IOWR(Xcvr_Base, 0x61, bInternalLoopback?0xFFFFFFFF:0x00000000);

		XCVR_RECONFIG_PMA_Channel(ALT_XCVR_RECONFIG_BASE, PhysicalChannel);
		XCVR_RECONFIG_PMA_Vod(ALT_XCVR_RECONFIG_BASE, TxVod);
		XCVR_RECONFIG_PMA_Eq(ALT_XCVR_RECONFIG_BASE, TxPostTap);
		XCVR_RECONFIG_PMA_PreEmphasisFirstPostTap(ALT_XCVR_RECONFIG_BASE, RxEq);


	}


	// start pattern
	for(i=0;i<CH_NUM;i++)
	{
		Generator_Base = gszChannelInfo[i].Generater_Base;
		Checker_Base = gszChannelInfo[i].Checker_Base;
		XCVR_PatStart(Generator_Base, Checker_Base, TestPattern);
	}

	// check status
	TimeStart = alt_nticks();
	Timeout = alt_nticks() + TimeDur;
	Time2Report = alt_nticks() + TimeReportDur;
	int m=0;
	while(!bDone){
		for(i=0;i<CH_NUM;i++){
			Checker_Base = gszChannelInfo[i].Checker_Base;
			if (!szError[i]){
				bError = FALSE;
				if (SPC_IsLocked(Checker_Base)){
					if (XCVR_PatCheck(Checker_Base, &NumCnt, &ErrCnt)){
						szNumCnt[i] = NumCnt;
						szErrCnt[i] = ErrCnt;
						if ((ErrCnt > 0) || (NumCnt == 0)){
							bError = TRUE;
							//
						}
					}else{
						bError = TRUE;
						printf("------>NG: Invalid Checker Counter\r\n");
					}
				}else{
					printf("------>NG: Checker failed to lock\r\n");
					bError = TRUE;
				}
				//
				if (bError){
					szElapsed[i] = alt_nticks()-TimeStart;
					nErrChNum++;
					szError[i] = TRUE;
					bPass = FALSE;
					XCVR_QueryChannelName(i, szChannelName);
					printf("%s=NG", szChannelName);
					printf("(NumCnt=%ld", NumCnt);
					printf(", ErrCnt=%ld", ErrCnt);
					printf(", Dur=%d second)\r\n", szElapsed[i]/alt_ticks_per_second());
					printf("test error \r\n");
					//bDone = TRUE;
					LED_AllOff( );
				}else{
					LEDG_lighton_count(i);
				}
			}
		} // for
		if (nErrChNum >= CH_NUM)
						bDone = TRUE;
		else if (IORD_ALTERA_AVALON_PIO_DATA(BUTTON_BASE) != 0x0f) // 4 button)
		{
			bDone = TRUE;
			printf("test terminate\r\n ");
		}

		if (alt_nticks() > Time2Report){
			TimeElapsed = alt_nticks() - TimeStart;
			printf("[%.f]",(float)TimeElapsed/alt_ticks_per_second());
			// report number count
			Time2Report = alt_nticks() + TimeReportDur;
			for(i=0;i<CH_NUM;i++){
				if (!szError[i])
				{
					XCVR_QueryChannelName(i, szChannelName);
					printf("%s pass ", szChannelName);
				}
			}
			printf("\r\n");
		}
	}

	// stop pattern
	for(i=0;i<CH_NUM;i++){
		Xcvr_Base = gszChannelInfo[i].Xcvr_Base;
		Generator_Base = gszChannelInfo[i].Generater_Base;
		Checker_Base = gszChannelInfo[i].Checker_Base;
		XCVR_PatStop(Generator_Base, Checker_Base);
	}
	return bPass;
}


