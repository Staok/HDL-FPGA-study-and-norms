#ifndef LED_H_
#define LED_H_


void LED_AllOn(void);
void LED_AllOff(void);
void LED_Display(alt_u32 Mask);
void LED_BlinkStart(alt_u32 TimeInterval); // unit in ms
void LED_BlinkStop(void);
void LED_LightCount(alt_u8 LightCount);
void LEDR_toggle_count(alt_u8 led_count);
void LEDR_AllOn(void);
void LEDG_lighton_count(alt_u8 led_count);
void LEDG_lightoff_count(alt_u8 led_count);

#endif /*LED_H_*/
