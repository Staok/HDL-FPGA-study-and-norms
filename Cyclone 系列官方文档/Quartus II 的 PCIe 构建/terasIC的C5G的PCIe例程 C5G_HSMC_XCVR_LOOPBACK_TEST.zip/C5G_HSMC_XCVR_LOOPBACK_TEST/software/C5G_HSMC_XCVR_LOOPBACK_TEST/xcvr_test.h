// --------------------------------------------------------------------
// Copyright (c) 2010 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------


/*
 * xcvr_test.h
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#ifndef XCVR_TEST_H_
#define XCVR_TEST_H_

#define PATTERN_NUM	6

typedef enum{
	PATTERN_PRBS7	=0x01,
	PATTERN_PRBS15	=0x02,
	PATTERN_PRBS23	=0x04,
	PATTERN_PRBS31	=0x08,
	PATTERN_HF	=0x10,
	PATTERN_LF	=0x20
}PAT_ID;

void XCVR_QueryPatternName(alt_u32 TestPattern, char szName[]);
bool XCVR_Test(alt_u32 XcvrBase, bool bInternalLoopback, alt_u32 ConfigBase, alt_u16 nChannel, alt_u8 TxVOD, alt_u8 TxPostTap, alt_u8 RxEQ, alt_u32 PatGenBase, alt_u32 PatCheckBase, alt_u32 TestPattern, alt_u32 TestTimeDur);

// group test
void XCVR_PatStart(alt_u32 PatGenBase, alt_u32 PatCheckBase, alt_u32 TestPattern);
void XCVR_PatStop(alt_u32 PatGenBase, alt_u32 PatCheckBase);
void XCVR_PatInsertError(alt_u32 PatGenBase, bool bInsertError);
bool XCVR_PatCheck(alt_u32 PatCheckBase, alt_u64 *pNumCnt, alt_u64 *pErrCnt);

#endif /* XCVR_TEST_H_ */
