// --------------------------------------------------------------------
// Copyright (c) 2010 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------


/*
 * st_pattern_checker.h
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#ifndef ST_PATTERN_CHECKER_H_
#define ST_PATTERN_CHECKER_H_


//SPC: AV-Stream Pattern Checker
#define SPC_STATUS			0x00	// RW
#define SPC_PATTERN_SET		0x01	// RW
#define SPC_COUNTER_CONTROL	0x02	// RW
#define SPC_NUM_BITS_LOW	0x03	// R
#define SPC_NUM_BITS_HI		0x04	// R
#define SPC_NUM_ERRORS_LOW	0x05	// R
#define SPC_NUM_ERRORS_HI	0x06	// R
#define SPC_CLOCK_SENSOR	0x07	// RW

#define SPC_STATUS_BIT_ENALBE	0x01
#define SPC_STATUS_BIT_LOCKED	0x02



#define SPC_PATTERN_BIT_PRBS7	0x01
#define SPC_PATTERN_BIT_PRBS15	0x02
#define SPC_PATTERN_BIT_PRBS23	0x04
#define SPC_PATTERN_BIT_PRBS31	0x08
#define SPC_PATTERN_BIT_HF		0x10
#define SPC_PATTERN_BIT_LF		0x20

#define SPC_COUNTER_BIT_SNAP	0x01
#define SPC_COUNTER_BIT_CLEAR	0x02
#define SPC_COUNTER_BIT_VALID	0x100

#define SPC_CLOCK_BIT_RESET		0x01
#define SPC_CLOCK_BIT_RUNNING	0x02

void SPC_Enable(alt_u32 BaseAddr, bool bEnable);
bool SPC_IsLocked(alt_u32 BaseAddr);
void SPC_PatternSet(alt_u32 BaseAddr, alt_u32 PatternID);
void SPC_CounterSnap(alt_u32 BaseAddr);
void SPC_CounterClear(alt_u32 BaseAddr);
bool SPC_IsCounterValid(alt_u32 BaseAddr);
alt_u64 SPC_NumCounterGet(alt_u32 BaseAddr);
alt_u64 SPC_ErrCounterGet(alt_u32 BaseAddr);
void SPC_ClockClear(alt_u32 BaseAddr);
bool SPC_IsClockRunning(alt_u32 BaseAddr);

#endif /* ST_PATTERN_CHECKER_H_ */
