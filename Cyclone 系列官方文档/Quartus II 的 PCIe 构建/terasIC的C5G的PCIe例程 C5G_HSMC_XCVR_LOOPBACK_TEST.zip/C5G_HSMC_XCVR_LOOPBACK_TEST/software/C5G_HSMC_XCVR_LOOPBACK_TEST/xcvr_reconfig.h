// --------------------------------------------------------------------
// Copyright (c) 2010 by Terasic Technologies Inc.
// --------------------------------------------------------------------
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// --------------------------------------------------------------------
//
//                     Terasic Technologies Inc
//                     E. Rd Sec. 1. JhuBei City,
//                     HsinChu County, Taiwan
//                     302
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// --------------------------------------------------------------------


/*
 * xcvr_reconfig.h
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#ifndef XCVR_RECONFIG_H_
#define XCVR_RECONFIG_H_

///////////////////////////
// PMA
#define PMA_BASE_ADDR			0x08

#define PMA_OFFSET_VOD			0x00
#define PMA_OFFSET_PEPT			0x01  // Pre-emphasis pre-tap
#define PMA_OFFSET_PEFPT		0x02  //Pre-emphasis first post-tap
#define PMA_OFFSET_PESPT		0x03  // Pre-emphasis second post-tap
#define PMA_OFFSET_RX_EQ_DCGAIN	0x10  // RX equalization DC gain
#define PMA_OFFSET_RX_EQ_CTRL	0x11	//RX equalization control
#define PMA_OFFSET_PRERSL		0x20	//Pre-CDR Reverse Serial Looppback
#define PMA_OFFSET_POSTRSL		0x21	// Post-CDR Reverse Serial Loopback

// register address
#define PMA_LCH			0x08	// logical channel number
#define PMA_PCH			0x09	// physical channel number
#define PMA_CS			0x0A  	// control and status
#define PMA_OFFSET		0x0B  	// pma offset
#define PMA_DATA		0x0C  	// data

// control and status register
#define PMA_CS_BIT_WRITE		0x01
#define PMA_CS_BIT_READ			0x02
#define PMA_CS_BIT_BUSY			0x100
#define PMA_CS_BIT_ERR			0x200

void XCVR_RECONFIG_PMA_Dump(alt_u32 BaseAddr, alt_u8 nChannel);
void XCVR_RECONFIG_PMA_Channel(alt_u32 BaseAddr, int nChannel);
bool XCVR_RECONFIG_PMA_Vod(alt_u32 BaseAddr, int Vod);
bool XCVR_RECONFIG_PMA_Eq(alt_u32 BaseAddr, int Eq);
bool XCVR_RECONFIG_PMA_PreEmphasisFirstPostTap(alt_u32 BaseAddr, int Tap);

#endif /* XCVR_RECONFIG_H_ */
