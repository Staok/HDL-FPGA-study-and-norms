/*
 * xcvr_reconfig.c
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

/*

Page 193 in xcvr_user_guide.pdf
Register-Based Write
Complete the following steps to perform a register-based write:
1. Read the control and status register busy bit (bit 8) until it is clear.
2. Write the logical channel number of the channel to be updated to the logical
channel number register.
3. Write the <feature> offset address.
4. Write the appropriate data value to the data register.
5. Write the control and status register write bit to 1��b1.
6. Read the control and status register busy bit. Continue to read the busy bit while
its value is one.
7. When busy = 0, the Transceiver Reconfiguration Controller has updated



Register-Based Read
Complete the following steps for a read:
1. Read the control and status register busy bit (bit 8) until it is clear.
2. Write the logical channel number of the channel to be read to the logical channel
number register.
3. Write the <feature> offset address.
4. Write the control and status register read bit to 1��b1.
5. Read the control and status register busy bit. Continue to read the busy until the
value is zero.
6. Read the data register to get the data.

 */

#include "terasic_includes.h"
#include "xcvr_reconfig.h"


// internal function prototype;
bool XCVR_RECONFIG_RegWrite(alt_u32 BaseAddr, alt_u32 GroupAddr, alt_u32 Offset, alt_u32 Data);
bool XCVR_RECONFIG_RegRead(alt_u32 BaseAddr, alt_u32 GroupAddr, alt_u32 Offset, alt_u32 *pData);

bool XCVR_RECONFIG_PmaRegWrite(alt_u32 BaseAddr, alt_u32 Offset, alt_u32 Data);
bool XCVR_RECONFIG_PmaRegRead(alt_u32 BaseAddr, alt_u32 Offset, alt_u32 *pData);




typedef struct{
	alt_u8 nOffset;
	char szRegName[128];
	alt_u32 Mask;
}REG_DEFINE;

void XCVR_RECONFIG_PMA_Dump(alt_u32 BaseAddr, alt_u8 nChannel){
	int i, nNum;
	alt_u32 Data;
	REG_DEFINE szReg[] = {
			{PMA_OFFSET_VOD, "Vod", 0x7F},
			{PMA_OFFSET_PEPT, "Pre-emphasis pre-tap", 0x3F},
			{PMA_OFFSET_PEFPT, "Pre-emphais first post-tap", 0x3F},
			{PMA_OFFSET_PESPT, "Pre-emphasis second post-tap", 0x3F},
			{PMA_OFFSET_RX_EQ_DCGAIN, "RX equalization DC gain", 0x0F},
			{PMA_OFFSET_RX_EQ_CTRL, "RX equalization control", 0x0F},  // write only?
			{PMA_OFFSET_PRERSL, "Pre-CDR Reverse Serial Loopback", 0x01}, // write only?
			{PMA_OFFSET_POSTRSL, "Post-CDR reverse Serial Looback", 0x01} // write only?
	};

	nNum = sizeof(szReg)/sizeof(szReg[0]);

	// select channel
	//IOWR(BaseAddr, PMA_LCH, nChannel);
	XCVR_RECONFIG_PMA_Channel(BaseAddr, nChannel);

	//XCVR_RECONFIG_PMA_Read(BaseAddr);
	Data = IORD(BaseAddr, PMA_LCH);
	printf("logical channel number:%xh\r\n", Data);
	Data = IORD(BaseAddr, PMA_PCH);
	printf("physical channel number:%xh\r\n", Data);
	Data = IORD(BaseAddr, PMA_CS);
	printf("control and status:%xh\r\n", Data);


	for(i=0;i<nNum;i++){
		XCVR_RECONFIG_PmaRegRead(BaseAddr, szReg[i].nOffset, &Data);

		//
		if (szReg[i].nOffset == PMA_OFFSET_PEPT || szReg[i].nOffset == PMA_OFFSET_PESPT){
			if (Data == 0x10) //5��b00000�V5��b10000: 0
				Data = 0;
		}

		printf("%s:%d\r\n", szReg[i].szRegName, Data & szReg[i].Mask);
	//	printf("%d:%d\r\n", i, Data & szReg[i].Mask);

	}

}

void XCVR_RECONFIG_PMA_Channel(alt_u32 BaseAddr, int nChannel){
	IOWR(BaseAddr, PMA_LCH, nChannel);
}


bool XCVR_RECONFIG_PMA_Vod(alt_u32 BaseAddr, int Vod){
	return XCVR_RECONFIG_PmaRegWrite(BaseAddr, PMA_OFFSET_VOD, Vod);
}


bool XCVR_RECONFIG_PMA_Eq(alt_u32 BaseAddr, int Eq){
	return XCVR_RECONFIG_PmaRegWrite(BaseAddr, PMA_OFFSET_RX_EQ_CTRL, Eq);
}

bool XCVR_RECONFIG_PMA_PreEmphasisFirstPostTap(alt_u32 BaseAddr, int Tap){
	return XCVR_RECONFIG_PmaRegWrite(BaseAddr, PMA_OFFSET_PEFPT, Tap);

}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

bool XCVR_RECONFIG_PmaRegWrite(alt_u32 BaseAddr, alt_u32 Offset, alt_u32 Data){
	return XCVR_RECONFIG_RegWrite(BaseAddr, PMA_BASE_ADDR, Offset, Data);
}


bool XCVR_RECONFIG_PmaRegRead(alt_u32 BaseAddr, alt_u32 Offset, alt_u32 *pData){
	return XCVR_RECONFIG_RegRead(BaseAddr, PMA_BASE_ADDR, Offset, pData);
}

bool XCVR_RECONFIG_RegWrite(alt_u32 BaseAddr, alt_u32 GroupAddr, alt_u32 Offset, alt_u32 Data){
	bool bSuccess = TRUE;
	alt_u32 Status;
	const int nMaxTry = 1000;
	int nTry = 0;

	// 1.
	do{
		Status = IORD(BaseAddr, GroupAddr+2);
	}while((Status & 0x100) && (nTry++ < nMaxTry));
	if (Status & 0x100)
		return FALSE;

	// 2.
	IOWR(BaseAddr, GroupAddr+0, 0);

	// 3.
	IOWR(BaseAddr, GroupAddr+3, Offset);

	// 4.
	IOWR(BaseAddr, GroupAddr+4, Data);

	// 5.
	IOWR(BaseAddr, GroupAddr+2, 0x01);

	// 6.
	nTry = 0;
	do{
		Status = IORD(BaseAddr, GroupAddr+2);
	}while((Status & 0x100) && (nTry++ < nMaxTry));
	if (Status & 0x100)
		return FALSE;


	return bSuccess;
}

bool XCVR_RECONFIG_RegRead(alt_u32 BaseAddr, alt_u32 GroupAddr, alt_u32 Offset, alt_u32 *pData){
	bool bSuccess = TRUE;
	alt_u32 Status;

	// 1.
	do{
		Status = IORD(BaseAddr, GroupAddr+2);
	}while(Status & 0x100);

	// 2.
	IOWR(BaseAddr, GroupAddr+0, 0);

	// 3.
	IOWR(BaseAddr, GroupAddr+0+3, Offset);

	// 4.
	IOWR(BaseAddr, GroupAddr+0+2, 0x02);

	// 5.
	do{
		Status = IORD(BaseAddr, GroupAddr+2);
	}while(Status & 0x100);

	// 6.
	*pData = IORD(BaseAddr, GroupAddr+4);

	return bSuccess;
}


