/*
 * xcvr_test.c
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */


#include "terasic_includes.h"
#include "xcvr_reconfig.h"
#include "st_pattern_gen.h"
#include "st_pattern_checker.h"
#include "xcvr_test.h"


bool XCVR_Config(alt_u32 XcvrBase, bool bInternalLoopback, alt_u32 ConfigBase, int nChannel, alt_u8 TxVOD, alt_u8 TxPostTap, alt_u8 RxEQ){
	bool bPass;
	// xcvr configure: internal loopback
	IOWR(XcvrBase, 0x61, bInternalLoopback?0xFFFFFFFF:0x00000000);

	// xcvr reconfigure configure
	XCVR_RECONFIG_PMA_Channel(ConfigBase, nChannel);

	bPass = XCVR_RECONFIG_PMA_Vod(ConfigBase, TxVOD);
	if (bPass)
		bPass = XCVR_RECONFIG_PMA_Eq(ConfigBase, RxEQ);
	if (bPass)
		bPass = XCVR_RECONFIG_PMA_PreEmphasisFirstPostTap(ConfigBase, TxPostTap);

	return bPass;
}


void XCVR_PatStart(alt_u32 PatGenBase, alt_u32 PatCheckBase, alt_u32 TestPattern){
	// start pattern generator
	SPG_Enable(PatGenBase,FALSE);
	SPG_InjectError(PatGenBase, FALSE);
	SPG_PatternSet(PatGenBase, TestPattern);
	SPG_Enable(PatGenBase,TRUE);

	// start pattern checker
	SPC_Enable(PatCheckBase, FALSE);
	SPC_PatternSet(PatCheckBase, TestPattern);
	SPC_CounterClear(PatCheckBase); // reset counter
	SPC_Enable(PatCheckBase, TRUE);

}

void XCVR_PatStop(alt_u32 PatGenBase, alt_u32 PatCheckBase){
	// start pattern generator
	SPG_Enable(PatGenBase,FALSE);

	// start pattern checker
	SPC_Enable(PatCheckBase, FALSE);
}

void XCVR_PatInsertError(alt_u32 PatGenBase, bool bInsertError){
	SPG_InjectError(PatGenBase, bInsertError);
}

bool XCVR_PatCheck(alt_u32 PatCheckBase, alt_u64 *pNumCnt, alt_u64 *pErrCnt){
	bool bSuccess;

	SPC_CounterSnap(PatCheckBase);
	bSuccess = SPC_IsCounterValid(PatCheckBase);
	if (bSuccess){
		*pNumCnt = SPC_NumCounterGet(PatCheckBase);
		*pErrCnt = SPC_ErrCounterGet(PatCheckBase);
	}else{
		*pNumCnt = 0;
		*pErrCnt = 0;
	}
	return bSuccess;
}



bool XCVR_PatTest(alt_u32 PatGenBase, alt_u32 PatCheckBase, alt_u32 TestPattern, alt_u32 TestTimeDur){
	bool bPass = TRUE, bLock = FALSE;
	alt_u32 Timeout;
	alt_u64 NumCnt=0, ErrCnt, PreNumCnt=0;

	// stop pattern generator & checker
	SPC_Enable(PatCheckBase, FALSE);
	SPG_Enable(PatGenBase,FALSE);

	// start pattern generator
	SPG_InjectError(PatGenBase, FALSE);
	SPG_PatternSet(PatGenBase, TestPattern);
	SPG_Enable(PatGenBase,TRUE);

	// start pattern checker
	SPC_PatternSet(PatCheckBase, TestPattern);
	SPC_CounterClear(PatCheckBase); // reset counter
	SPC_Enable(PatCheckBase, TRUE);

	usleep(50*1000);

	Timeout = alt_nticks() + TestTimeDur;
	while(bPass && alt_nticks() < Timeout){
		if (SPC_IsLocked(PatCheckBase)){
			bLock = TRUE;
			SPC_CounterSnap(PatCheckBase);
			bPass = SPC_IsCounterValid(PatCheckBase);
			if (bPass){
				NumCnt = SPC_NumCounterGet(PatCheckBase);
				ErrCnt = SPC_ErrCounterGet(PatCheckBase);
				if ((ErrCnt > 0) || (NumCnt == PreNumCnt)){
					bPass = FALSE;
				}
				//
				PreNumCnt = NumCnt;
			}
		} // if

	} // while

	if (bPass && !bLock){
		bPass = FALSE;
		printf("----------------- NG: Checker Lock fail.\r\n");
	}

	//if (!bPass)
	//	printf("ffff");

	if (bPass && (NumCnt == 0))
		bPass = FALSE; // NumCnt should > 0
	//printf("-->%d, %d/%d\r\n", bPass?1:0, ErrCnt, NumCnt);

//	printf("ErrCnt:%ld,", ErrCnt);
//	printf("NumCnt:%ld\n", NumCnt);


	// test with inject error
	if (bPass){
		//printf("inject error test");//(add this statement will avoid inject work well, I don't know why?)\r\n");
		//usleep(100*1000);
		SPG_InjectError(PatGenBase, TRUE);
		usleep(20*1000); // wait error is detect
		SPC_CounterSnap(PatCheckBase);
		bPass = SPC_IsCounterValid(PatCheckBase);
		if (bPass){
			ErrCnt = SPC_ErrCounterGet(PatCheckBase);
			if (ErrCnt != 1)
				bPass = FALSE;
		}else{
			printf("xxxx");
		}

		SPG_InjectError(PatGenBase, FALSE);
	}


	return bPass;

}


bool XCVR_Test(alt_u32 XcvrBase, bool bInternalLoopback, alt_u32 ConfigBase, alt_u16 nChannel, alt_u8 TxVOD, alt_u8 TxPostTap, alt_u8 RxEQ, alt_u32 PatGenBase, alt_u32 PatCheckBase, alt_u32 TestPattern, alt_u32 TestTimeDur){
	bool bPass;

	bPass = XCVR_Config(XcvrBase, bInternalLoopback, ConfigBase, nChannel, TxVOD, TxPostTap, RxEQ);
	if (!bPass){
		printf("-------------------- XCVR_Config NG\r\n");
	}else{
		//usleep(20*1000);
		bPass = XCVR_PatTest(PatGenBase, PatCheckBase, TestPattern, TestTimeDur);
	}
	return bPass;
}

void XCVR_QueryPatternName(alt_u32 TestPattern, char szName[]){
	switch(TestPattern){
		case PATTERN_PRBS7: strcpy(szName, "PRBS7"); break;
		case PATTERN_PRBS15: strcpy(szName, "PRBS15"); break;
		case PATTERN_PRBS23: strcpy(szName, "PRBS23"); break;
		case PATTERN_PRBS31: strcpy(szName, "PRBS31"); break;
		case PATTERN_HF: strcpy(szName, "High-Frequency"); break;
		case PATTERN_LF: strcpy(szName, "Low-Frequency"); break;
	}

}
