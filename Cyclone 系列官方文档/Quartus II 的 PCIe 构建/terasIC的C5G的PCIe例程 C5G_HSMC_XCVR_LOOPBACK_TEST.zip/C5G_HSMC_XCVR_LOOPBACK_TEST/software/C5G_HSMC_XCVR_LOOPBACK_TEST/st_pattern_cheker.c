/*
 * st_pattern_cheker.c
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#include "terasic_includes.h"
#include "st_pattern_checker.h"

void SPC_Enable(alt_u32 BaseAddr, bool bEnable){
	IOWR(BaseAddr, SPC_STATUS, bEnable?SPC_STATUS_BIT_ENALBE:0x00);
}

bool SPC_IsLocked(alt_u32 BaseAddr){
	alt_u32 Data;
	bool bLocked;
	Data = IORD(BaseAddr, SPC_STATUS);
	bLocked = (Data & SPC_STATUS_BIT_LOCKED)?TRUE:FALSE;

	return bLocked;
}


void SPC_PatternSet(alt_u32 BaseAddr, alt_u32 PatternID){
	IOWR(BaseAddr, SPC_PATTERN_SET, PatternID);
}


alt_u64 SPC_NumCounterGet(alt_u32 BaseAddr){
	alt_u64 cnt;
	alt_u32 cnt_h, cnt_l;
	cnt_l = IORD(BaseAddr, SPC_NUM_BITS_LOW);
	cnt_h = IORD(BaseAddr, SPC_NUM_BITS_HI);
	cnt = cnt_l | (cnt_h << 32);

	return cnt;

}

alt_u64 SPC_ErrCounterGet(alt_u32 BaseAddr){
	alt_u64 cnt;
	alt_u32 cnt_h, cnt_l;
	cnt_l = IORD(BaseAddr, SPC_NUM_ERRORS_LOW);
	cnt_h = IORD(BaseAddr, SPC_NUM_ERRORS_HI);
	cnt = cnt_l | (cnt_h << 32);

	return cnt;

}

void SPC_CounterSnap(alt_u32 BaseAddr){
	IOWR(BaseAddr, SPC_COUNTER_CONTROL, SPC_COUNTER_BIT_SNAP);
}

void SPC_CounterClear(alt_u32 BaseAddr){
	IOWR(BaseAddr, SPC_COUNTER_CONTROL, SPC_COUNTER_BIT_CLEAR);
}

bool SPC_IsCounterValid(alt_u32 BaseAddr){
	bool bValid;
	alt_u32 Data;
	Data = IORD(BaseAddr, SPC_COUNTER_CONTROL);
	bValid = (Data & SPC_COUNTER_BIT_VALID)?TRUE:FALSE;

	return bValid;

}

void SPC_ClockClear(alt_u32 BaseAddr){
	IOWR(BaseAddr, SPC_CLOCK_SENSOR, SPC_CLOCK_BIT_RESET);

}

bool SPC_IsClockRunning(alt_u32 BaseAddr){
	bool bRunning;
	alt_u32 Data;
	Data = IORD(BaseAddr, SPC_CLOCK_SENSOR);
	bRunning = (Data & SPC_CLOCK_BIT_RUNNING)?TRUE:FALSE;

	return bRunning;
}

