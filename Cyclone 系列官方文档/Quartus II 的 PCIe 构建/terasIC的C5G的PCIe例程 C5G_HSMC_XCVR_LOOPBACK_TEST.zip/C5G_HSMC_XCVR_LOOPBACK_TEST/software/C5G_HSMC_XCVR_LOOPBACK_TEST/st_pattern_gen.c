/*
 * st_pattern_gen.c
 *
 *  Created on: 2012/3/22
 *      Author: Richard
 */

#include "terasic_includes.h"
#include "st_pattern_gen.h"

void SPG_Enable(alt_u32 BaseAddr, bool bEnable){
	IOWR(BaseAddr, SPG_ENALBE, bEnable?SPG_INJET_ERROR_BIT_ENABLE:0x00);
}

void SPG_PatternSet(alt_u32 BaseAddr, alt_u32 PatternID){
	IOWR(BaseAddr, SPG_PATTERN_SELECT, PatternID);
}


void SPG_InjectError(alt_u32 BaseAddr, bool bEnable){
	IOWR(BaseAddr, SPG_INJECT_ERROR, bEnable?SPG_INJET_ERROR_BIT_ENABLE:0x00);
}

void SPG_Preamble(alt_u32 BaseAddr, bool bEnable, alt_u8 NumBeats){
	alt_u32 Data = 0;
	if (bEnable){
		Data |= SPG_PREAMBLE_BIT_ENABLE;
		Data |= NumBeats << 8;
	}
	IOWR(BaseAddr, SPG_PREAMBLE_CONTROL, Data);
}

void SPG_PreambleCharSet(alt_u32 BaseAddr, alt_u8 HiChar, alt_u32 LowChar){
	IOWR(BaseAddr, SPG_PREAMBLE_CHAR_LOW, LowChar);
	IOWR(BaseAddr, SPG_PREAMBLE_CHAR_HI, HiChar);

}
