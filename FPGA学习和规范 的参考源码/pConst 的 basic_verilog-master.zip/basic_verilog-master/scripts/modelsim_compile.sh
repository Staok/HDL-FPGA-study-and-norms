#!/bin/bash

#  modelsim_compile.sh
#  Konstantin Pavlov, pavlovconst@gmail.com
#
#  This is a support script for launching "Modelsim compile script" on Linux


vsim -do modelsim_compile.tcl
