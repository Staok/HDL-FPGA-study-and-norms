
fast_counter_iterative_test project
-----------------------------------

This project shows how to make iterative compilation for Intel / Altera Quartus FPGA

We create a bunch of generated Quartus project copies which differ only one variable
All projects get compiled in parallel collecting FMAX data

This particular test shows FMAX advantage of using 'fast_counter.sv' module

Launch compilation using "make -j" command

