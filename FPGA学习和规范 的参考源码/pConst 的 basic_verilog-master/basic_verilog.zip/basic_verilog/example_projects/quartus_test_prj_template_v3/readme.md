
Quartus IDE test project template